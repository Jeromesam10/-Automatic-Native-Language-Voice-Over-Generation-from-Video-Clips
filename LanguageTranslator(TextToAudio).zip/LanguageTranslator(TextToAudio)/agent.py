from deep_translator import GoogleTranslator
from gtts import gTTS


def run(text, target_language, output_file="output.mp3"):
    """
    Translate text and save speech as an MP3.

    Returns:
        dict:
        {
            "translated_text": "...",
            "audio_path": "output.mp3"
        }
    """

    translated = GoogleTranslator(
        source="auto",
        target=target_language
    ).translate(text)

    tts = gTTS(
        text=translated,
        lang=target_language
    )

    tts.save(output_file)

    return {
        "translated_text": translated,
        "audio_path": output_file
    }