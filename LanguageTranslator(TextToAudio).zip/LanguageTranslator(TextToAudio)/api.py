from fastapi import FastAPI
from pydantic import BaseModel

from agent import run

app = FastAPI()


class TranslatorRequest(BaseModel):
    text: str
    language: str


@app.post("/translate")
def translate(request: TranslatorRequest):

    result = run(
        request.text,
        request.language
    )

    return result